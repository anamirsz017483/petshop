

**footer do cachorro**



<footer>

&nbsp;   <div class="footer-container">

&nbsp;       <div class="footer-section">

&nbsp;           <h3>PetinhoShops</h3>

&nbsp;           <p>Cuidando do seu pet com carinho e qualidade.</p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Links</h3>

&nbsp;           <p><a href="inicio.html">Início</a></p>

&nbsp;           <p><a href="produtos.html">Produtos</a></p>

&nbsp;           <p><a href="contato.html">Contato</a></p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Contato</h3>

&nbsp;           <p>Email: contato@petinhoshops.com</p>

&nbsp;           <p>WhatsApp: (11) 99999-9999</p>

&nbsp;       </div>

&nbsp;   </div>

&nbsp;   <div class="footer-bottom">

&nbsp;       <p>© 2026 Ana Rosa da cruz miranda - Todos os direitos reservados.</p>

&nbsp;   </div>

</footer>



**footer do coelho**





<footer>

&nbsp;   <div class="footer-container">

&nbsp;       <div class="footer-section">

&nbsp;           <h3>PetinhoShops</h3>

&nbsp;           <p>Cuidando do seu pet com carinho e qualidade.</p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Links</h3>

&nbsp;           <p><a href="inicio.html">Início</a></p>

&nbsp;           <p><a href="produtos.html">Produtos</a></p>

&nbsp;           <p><a href="contato.html">Contato</a></p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Contato</h3>

&nbsp;           <p>Email: contato@petinhoshops.com</p>

&nbsp;           <p>WhatsApp: (11) 99999-9999</p>

&nbsp;       </div>

&nbsp;   </div>

&nbsp;   <div class="footer-bottom">

&nbsp;       <p>© 2026 Ana Rosa da cruz miranda - Todos os direitos reservados.</p>

&nbsp;   </div>

</footer>





**footer do gato** 





<footer>

&nbsp;   <div class="footer-container">

&nbsp;       <div class="footer-section">

&nbsp;           <h3>PetinhoShops</h3>

&nbsp;           <p>Cuidando do seu pet com carinho e qualidade.</p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Links</h3>

&nbsp;           <p><a href="inicio.html">Início</a></p>

&nbsp;           <p><a href="produtos.html">Produtos</a></p>

&nbsp;           <p><a href="contato.html">Contato</a></p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Contato</h3>

&nbsp;           <p>Email: contato@petinhoshops.com</p>

&nbsp;           <p>WhatsApp: (11) 99999-9999</p>

&nbsp;       </div>

&nbsp;   </div>

&nbsp;   <div class="footer-bottom">

&nbsp;       <p>© 2026 Ana Rosa da cruz miranda - Todos os direitos reservados.</p>

&nbsp;   </div>

</footer>



**footer do panda** 





<footer>

&nbsp;   <div class="footer-container">

&nbsp;       <div class="footer-section">

&nbsp;           <h3>PetinhoShops</h3>

&nbsp;           <p>Cuidando do seu pet com carinho e qualidade.</p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Links</h3>

&nbsp;           <p><a href="inicio.html">Início</a></p>

&nbsp;           <p><a href="produtos.html">Produtos</a></p>

&nbsp;           <p><a href="contato.html">Contato</a></p>

&nbsp;       </div>

&nbsp;       <div class="footer-section">

&nbsp;           <h3>Contato</h3>

&nbsp;           <p>Email: contato@petinhoshops.com</p>

&nbsp;           <p>WhatsApp: (11) 99999-9999</p>

&nbsp;       </div>

&nbsp;   </div>

&nbsp;   <div class="footer-bottom">

&nbsp;       <p>© 2026 Ana Rosa da cruz miranda - Todos os direitos reservados.</p>

&nbsp;   </div>

</footer>

