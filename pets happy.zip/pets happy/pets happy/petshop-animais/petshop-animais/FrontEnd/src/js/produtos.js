const API_BASE = "http://localhost:8080/api/produtos";

const categoriasMap = {
  1: {
    nome: "Cachorros 🐶",
    plural: "Cachorros",
    hero: "Produtos para Cachorros 🐶",
    subtitulo: "Tudo para cuidar do seu cão com conforto, saúde e carinho.",
    corHeader: "#7b4a1b",
    corHero: "#e9ccff",
    busca: "Buscar produtos para cachorros...",
    fallback: [
      {
        id: 1,
        nome: "Ração Premium",
        descricao: "Ração completa para cães adultos, com nutrientes essenciais para energia, pelagem bonita e uma rotina saudável.",
        preco: 79.90,
        imagem: "assets/produtos/cachorro-racao.svg",
        emoji: "🥣"
      },
      {
        id: 2,
        nome: "Coleira Ajustável",
        descricao: "Coleira resistente e confortável para passeios mais seguros, com ajuste fácil e encaixe prático.",
        preco: 34.90,
        imagem: "assets/produtos/cachorro-coleira.svg",
        emoji: "🦴"
      },
      {
        id: 3,
        nome: "Caminha Macia",
        descricao: "Caminha aconchegante para descanso diário, com toque suave e apoio confortável para o pet.",
        preco: 129.90,
        imagem: "assets/produtos/cachorro-caminha.svg",
        emoji: "🛏️"
      },
      {
        id: 4,
        nome: "Brinquedo Mordedor",
        descricao: "Brinquedo interativo que ajuda na distração, no gasto de energia e no bem-estar do cão.",
        preco: 24.90,
        imagem: "assets/produtos/cachorro-brinquedo.svg",
        emoji: "🧸"
      }
    ]
  },
  2: {
    nome: "Gatos 🐱",
    plural: "Gatos",
    hero: "Produtos para Gatos 🐱",
    subtitulo: "Itens para deixar o seu gato feliz, ativo e bem cuidado.",
    corHeader: "#e67e22",
    corHero: "#fff3b0",
    busca: "Buscar produtos para gatos...",
    fallback: [
      {
        id: 5,
        nome: "Ração Sabor Frango",
        descricao: "Alimento balanceado para gatos, com sabor agradável e composição pensada para a saúde diária.",
        preco: 44.90,
        imagem: "assets/produtos/gato-racao.svg",
        emoji: "🥣"
      },
      {
        id: 6,
        nome: "Arranhador",
        descricao: "Arranhador funcional para estimular o comportamento natural do gato e proteger os móveis.",
        preco: 89.90,
        imagem: "assets/produtos/gato-arranhador.svg",
        emoji: "🪵"
      },
      {
        id: 7,
        nome: "Fonte de Água",
        descricao: "Fonte com fluxo contínuo para incentivar a hidratação e deixar a água sempre fresca.",
        preco: 129.90,
        imagem: "assets/produtos/gato-fonte.svg",
        emoji: "💧"
      },
      {
        id: 8,
        nome: "Caixa de Areia",
        descricao: "Caixa prática para higiene diária, com uso simples e limpeza facilitada.",
        preco: 79.90,
        imagem: "assets/produtos/gato-caixa-areia.svg",
        emoji: "🧼"
      }
    ]
  },
  3: {
    nome: "Coelhos 🐰",
    plural: "Coelhos",
    hero: "Produtos para Coelhos 🐰",
    subtitulo: "Tudo para cuidar do seu coelhinho com conforto, saúde e carinho.",
    corHeader: "#7b4a1b",
    corHero: "#f5e7d3",
    busca: "Buscar produtos para coelhos...",
    fallback: [
      {
        id: 9,
        nome: "Alimento para Coelhos",
        descricao: "Alimento rico em fibras e nutrientes naturais para uma rotina alimentar equilibrada.",
        preco: 39.90,
        imagem: "assets/produtos/coelho-alimento.svg",
        emoji: "🥕"
      },
      {
        id: 10,
        nome: "Casinha de Coelho",
        descricao: "Casinha confortável e segura para descanso, abrigo e momentos de tranquilidade.",
        preco: 119.90,
        imagem: "assets/produtos/coelho-casinha.svg",
        emoji: "🏠"
      },
      {
        id: 11,
        nome: "Feno Natural",
        descricao: "Feno natural essencial para a digestão e para uma alimentação saudável do coelhinho.",
        preco: 24.90,
        imagem: "assets/produtos/coelho-feno.svg",
        emoji: "🌿"
      },
      {
        id: 12,
        nome: "Brinquedo Interativo",
        descricao: "Brinquedo leve e divertido que estimula movimento, curiosidade e atividade física.",
        preco: 29.90,
        imagem: "assets/produtos/coelho-brinquedo.svg",
        emoji: "🎾"
      }
    ]
  },
  4: {
    nome: "Pandas 🐼",
    plural: "Pandas",
    hero: "Produtos para Pandas 🐼",
    subtitulo: "Acessórios e itens especiais para um panda cheio de estilo.",
    corHeader: "#0f4d2f",
    corHero: "#c8f7c5",
    busca: "Buscar produtos para pandas...",
    fallback: [
      {
        id: 13,
        nome: "Bambu Selecionado",
        descricao: "Bambu fresco e selecionado para uma alimentação natural e cheia de energia.",
        preco: 49.90,
        imagem: "assets/produtos/panda-bambu.svg",
        emoji: "🎋"
      },
      {
        id: 14,
        nome: "Pelúcia Panda",
        descricao: "Pelúcia fofinha para companhia, conforto e momentos de diversão.",
        preco: 34.90,
        imagem: "assets/produtos/panda-pelucia.svg",
        emoji: "🧸"
      },
      {
        id: 15,
        nome: "Tapete Confortável",
        descricao: "Tapete macio para descanso agradável e sensação de aconchego.",
        preco: 94.90,
        imagem: "assets/produtos/panda-tapete.svg",
        emoji: "🛋️"
      },
      {
        id: 16,
        nome: "Kit Enriquecimento",
        descricao: "Kit com itens para estímulo diário, diversão e rotina mais ativa.",
        preco: 59.90,
        imagem: "assets/produtos/panda-kit.svg",
        emoji: "🎮"
      }
    ]
  }
};

function getCategoriaIdFromPage() {
  const params = new URLSearchParams(window.location.search);
  const q = params.get("categoria");
  if (q) return Number(q);

  const bodyClass = document.body?.dataset?.categoriaId;
  if (bodyClass) return Number(bodyClass);

  return null;
}

function formatarPreco(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function montarCard(prod, allowComprar = true) {
  const card = document.createElement("article");
  card.className = "produto-card";

  const imageHtml = prod.imagem
    ? `<img src="${prod.imagem}" alt="${prod.nome || 'Produto'}" loading="lazy">`
    : `<div class="emoji-produto">${prod.emoji || "🐾"}</div>`;

  card.innerHTML = `
    ${imageHtml}
    <h3><a href="produto.html?id=${prod.id || ''}" style="color:inherit;text-decoration:underline">${prod.nome || ""}</a></h3>
    <p class="produto-id">ID do produto: <strong>#${prod.id ?? "—"}</strong></p>
    <p>${prod.descricao || ""}</p>
    <p class="preco">R$ ${formatarPreco(prod.preco)}</p>
    ${allowComprar ? '<button class="btn-comprar" type="button">Comprar</button>' : ''}
  `;

  return card;
}

async function buscarProdutosDaApi(categoriaId) {
  try {
    const res = await fetch(`${API_BASE}/categoria/${categoriaId}`);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch (e) {
    return [];
  }
}

function combinarProdutos(apiProdutos, fallbackProdutos) {
  const lista = [];

  for (let i = 0; i < 4; i++) {
    const fallback = fallbackProdutos[i];
    const api = apiProdutos[i];

    if (api) {
      lista.push({
        id: api.id ?? fallback?.id ?? null,
        nome: api.nome || fallback?.nome || "Produto",
        descricao: api.descricao || fallback?.descricao || "",
        preco: api.preco ?? fallback?.preco ?? 0,
        imagem: api.imagem || fallback?.imagem || "",
        emoji: api.emoji || fallback?.emoji || "🐾"
      });
    } else if (fallback) {
      lista.push({ ...fallback });
    }
  }

  return lista.slice(0, 4);
}

async function renderCategoriaUnica(categoriaId) {
  const area = document.getElementById("areaProdutos");
  const msg = document.getElementById("mensagem");
  const titulo = document.getElementById("titulo");
  const subtitulo = document.getElementById("subtitulo");

  const cat = categoriasMap[categoriaId];
  if (!cat) {
    if (titulo) titulo.textContent = "Produtos por Categoria";
    if (subtitulo) subtitulo.textContent = "Escolha uma categoria.";
    if (msg) {
      msg.style.display = "block";
      msg.textContent = "Categoria inválida.";
    }
    return;
  }

  const header = document.querySelector("header");
  const hero = document.querySelector(".hero");
  if (header) header.style.background = cat.corHeader;
  if (hero) hero.style.background = cat.corHero;

  if (titulo) titulo.textContent = cat.hero;
  if (subtitulo) subtitulo.textContent = cat.subtitulo;

  const apiProdutos = await buscarProdutosDaApi(categoriaId);
  const produtos = combinarProdutos(apiProdutos, cat.fallback);

  if (area) area.innerHTML = "";
  if (msg) msg.style.display = "none";

  const bloco = document.createElement("section");
  bloco.className = "categoria-bloco";

  const h2 = document.createElement("h2");
  h2.className = "categoria-titulo";
  h2.textContent = cat.nome;

  const grid = document.createElement("div");
  grid.className = "produtos-grid";

  produtos.forEach((prod) => grid.appendChild(montarCard(prod, true)));

  bloco.appendChild(h2);
  bloco.appendChild(grid);
  if (area) area.appendChild(bloco);
}

async function renderTodasCategorias() {
  const area = document.getElementById("areaProdutos");
  const msg = document.getElementById("mensagem");
  const titulo = document.getElementById("titulo");
  const subtitulo = document.getElementById("subtitulo");

  if (titulo) titulo.textContent = "Produtos por Categoria";
  if (subtitulo) subtitulo.textContent = "Cachorros, Gatos, Coelhos e Pandas";

  if (area) area.innerHTML = "";
  if (msg) msg.style.display = "none";

  const ids = [1, 2, 3, 4];

  for (const id of ids) {
    const cat = categoriasMap[id];
    const apiProdutos = await buscarProdutosDaApi(id);
    const produtos = combinarProdutos(apiProdutos, cat.fallback);

    const bloco = document.createElement("section");
    bloco.className = "categoria-bloco";

    const cab = document.createElement("div");
    cab.className = "cabecalho-categoria";
    cab.innerHTML = `
      <h2>${cat.nome}</h2>
      <a class="link-categoria" href="produtos.html?categoria=${id}">Ver todos</a>
    `;

    const grid = document.createElement("div");
    grid.className = "produtos-grid";

    produtos.forEach((prod) => grid.appendChild(montarCard(prod, true)));

    bloco.appendChild(cab);
    bloco.appendChild(grid);
    if (area) area.appendChild(bloco);
  }
}

async function inicializarPagina() {
  const categoriaId = getCategoriaIdFromPage();

  if (categoriaId) {
    await renderCategoriaUnica(categoriaId);
  } else {
    await renderTodasCategorias();
  }
}

window.buscarProdutosNaPagina = function buscarProdutosNaPagina() {
  const termo = (document.getElementById("pesquisa")?.value || "").toLowerCase();
  document.querySelectorAll(".produto-card").forEach((card) => {
    const texto = card.innerText.toLowerCase();
    card.style.display = texto.includes(termo) ? "block" : "none";
  });
};

document.addEventListener("DOMContentLoaded", inicializarPagina);
