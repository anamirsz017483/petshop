const API_BASE = "http://localhost:8080/api/produtos";

const CATEGORIAS = {
  1: "Cachorros",
  2: "Gatos",
  3: "Coelhos",
  4: "Pandas"
};

const CATALOGO_FALLBACK = {
  1: { id: 1, nome: "Ração Premium", descricao: "Ração completa para cães adultos, com nutrientes essenciais para energia, pelagem bonita e uma rotina saudável.", preco: 79.90, idCategoria: 1, estoque: 18 },
  2: { id: 2, nome: "Coleira Ajustável", descricao: "Coleira resistente e confortável para passeios mais seguros, com ajuste fácil e encaixe prático.", preco: 34.90, idCategoria: 1, estoque: 32 },
  3: { id: 3, nome: "Caminha Macia", descricao: "Caminha aconchegante para descanso diário, com toque suave e apoio confortável para o pet.", preco: 129.90, idCategoria: 1, estoque: 12 },
  4: { id: 4, nome: "Brinquedo Mordedor", descricao: "Brinquedo interativo que ajuda na distração, no gasto de energia e no bem-estar do cão.", preco: 24.90, idCategoria: 1, estoque: 45 },
  5: { id: 5, nome: "Ração Sabor Frango", descricao: "Alimento balanceado para gatos, com sabor agradável e composição pensada para a saúde diária.", preco: 44.90, idCategoria: 2, estoque: 20 },
  6: { id: 6, nome: "Arranhador", descricao: "Arranhador funcional para estimular o comportamento natural do gato e proteger os móveis.", preco: 89.90, idCategoria: 2, estoque: 11 },
  7: { id: 7, nome: "Fonte de Água", descricao: "Fonte com fluxo contínuo para incentivar a hidratação e deixar a água sempre fresca.", preco: 129.90, idCategoria: 2, estoque: 9 },
  8: { id: 8, nome: "Caixa de Areia", descricao: "Caixa prática para higiene diária, com uso simples e limpeza facilitada.", preco: 79.90, idCategoria: 2, estoque: 22 },
  9: { id: 9, nome: "Alimento para Coelhos", descricao: "Alimento rico em fibras e nutrientes naturais para uma rotina alimentar equilibrada.", preco: 39.90, idCategoria: 3, estoque: 27 },
  10: { id: 10, nome: "Casinha de Coelho", descricao: "Casinha confortável e segura para descanso, abrigo e momentos de tranquilidade.", preco: 119.90, idCategoria: 3, estoque: 8 },
  11: { id: 11, nome: "Feno Natural", descricao: "Feno natural essencial para a digestão e para uma alimentação saudável do coelhinho.", preco: 24.90, idCategoria: 3, estoque: 40 },
  12: { id: 12, nome: "Brinquedo Interativo", descricao: "Brinquedo leve e divertido que estimula movimento, curiosidade e atividade física.", preco: 29.90, idCategoria: 3, estoque: 17 },
  13: { id: 13, nome: "Bambu Selecionado", descricao: "Bambu fresco e selecionado para uma alimentação natural e cheia de energia.", preco: 49.90, idCategoria: 4, estoque: 14 },
  14: { id: 14, nome: "Pelúcia Panda", descricao: "Pelúcia fofinha para companhia, conforto e momentos de diversão.", preco: 34.90, idCategoria: 4, estoque: 25 },
  15: { id: 15, nome: "Tapete Confortável", descricao: "Tapete macio para descanso agradável e sensação de aconchego.", preco: 94.90, idCategoria: 4, estoque: 10 },
  16: { id: 16, nome: "Kit Enriquecimento", descricao: "Kit com itens para estímulo diário, diversão e rotina mais ativa.", preco: 59.90, idCategoria: 4, estoque: 16 }
};

function formatarPreco(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function getIdProduto() {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));
  return Number.isFinite(id) && id > 0 ? id : null;
}

function getProdutoFallback(id) {
  const produto = CATALOGO_FALLBACK[id];
  return produto ? { ...produto } : null;
}

function criarLinha(label, value) {
  const p = document.createElement("p");
  p.innerHTML = `<strong>${label}:</strong> ${value}`;
  return p;
}

function renderizarProduto(area, titulo, subtitulo, produto, origem = "") {
  const categoria = CATEGORIAS[produto.idCategoria] || "Categoria não informada";
  const preco = formatarPreco(produto.preco);
  const estoque = Number(produto.estoque ?? 0);

  if (titulo) titulo.textContent = `${produto.nome || "Produto"}`;
  if (subtitulo) subtitulo.textContent = `${categoria}${origem ? ` • ${origem}` : ""}`;
  document.title = `${produto.nome || "Produto"} - PetinhoShops`;

  if (!area) return;
  area.innerHTML = "";

  const card = document.createElement("section");
  card.className = "produto-detalhe-card";

  card.innerHTML = `
      <div class="produto-detalhe-topo">
        <div class="produto-imagem-grande">
          <span>🐾</span>
        </div>
        <div class="produto-resumo">
          <p class="produto-categoria">${categoria}</p>
          <h2>${produto.nome || "Produto"}</h2>
          <p class="produto-id-detalhe"><strong>ID:</strong> #${produto.id ?? "—"}</p>
          <p class="produto-descricao">${produto.descricao || "Sem descrição disponível."}</p>
          <p class="produto-preco">R$ ${preco}</p>
          <p class="produto-estoque">Quantidade em estoque: <strong>${estoque}</strong></p>
          <p class="produto-status ${estoque > 0 ? "estoque-ok" : "estoque-zero"}">${estoque > 0 ? "Disponível para compra" : "Sem estoque no momento"}</p>
        </div>
      </div>
    `;

  const detalhes = document.createElement("div");
  detalhes.className = "produto-detalhes-lista";
  detalhes.appendChild(criarLinha("ID", `#${produto.id ?? "—"}`));
  detalhes.appendChild(criarLinha("Categoria", categoria));
  detalhes.appendChild(criarLinha("Preço", `R$ ${preco}`));
  detalhes.appendChild(criarLinha("Estoque", estoque));
  detalhes.appendChild(criarLinha("Descrição", produto.descricao || "Sem descrição disponível."));

  card.appendChild(detalhes);
  area.appendChild(card);
}

async function carregarProduto() {
  const area = document.getElementById("produtoDetalhe");
  const titulo = document.getElementById("tituloProduto");
  const subtitulo = document.getElementById("subtituloProduto");
  const id = getIdProduto();

  if (!id) {
    if (area) area.innerHTML = '<div class="produto-mensagem">Produto não encontrado. O link precisa trazer <strong>?id=</strong>.</div>';
    if (titulo) titulo.textContent = "Produto";
    if (subtitulo) subtitulo.textContent = "O id do produto não foi informado.";
    document.title = "Produto - PetinhoShops";
    return;
  }

  let produto = null;
  let origem = "backend";

  try {
    const resposta = await fetch(`${API_BASE}/${id}`);
    if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
    produto = await resposta.json();
  } catch (erro) {
    produto = getProdutoFallback(id);
    origem = "dados locais";
  }

  if (!produto) {
    if (area) area.innerHTML = '<div class="produto-mensagem">Não foi possível carregar este produto.</div>';
    if (titulo) titulo.textContent = "Produto";
    if (subtitulo) subtitulo.textContent = "Tente novamente.";
    document.title = "Produto - PetinhoShops";
    return;
  }

  renderizarProduto(area, titulo, subtitulo, produto, origem);
}

document.addEventListener("DOMContentLoaded", carregarProduto);
