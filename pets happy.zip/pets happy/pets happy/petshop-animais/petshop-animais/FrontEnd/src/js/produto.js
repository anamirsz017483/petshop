const API_BASE = "http://localhost:8080/api/produtos";

const CATEGORIAS = {
  1: "Cachorros",
  2: "Gatos",
  3: "Coelhos",
  4: "Pandas"
};

function formatarPreco(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function getIdProduto() {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));
  return Number.isFinite(id) && id > 0 ? id : null;
}

function criarLinha(label, value) {
  const p = document.createElement("p");
  p.innerHTML = `<strong>${label}:</strong> ${value}`;
  return p;
}

async function carregarProduto() {
  const area = document.getElementById("produtoDetalhe");
  const titulo = document.getElementById("tituloProduto");
  const subtitulo = document.getElementById("subtituloProduto");
  const id = getIdProduto();

  if (!id) {
    if (area) area.innerHTML = '<div class="produto-mensagem">Produto não encontrado.</div>';
    if (titulo) titulo.textContent = "Produto";
    if (subtitulo) subtitulo.textContent = "O id do produto não foi informado.";
    return;
  }

  try {
    const resposta = await fetch(`${API_BASE}/${id}`);
    if (!resposta.ok) throw new Error("Produto não encontrado");

    const produto = await resposta.json();
    const categoria = CATEGORIAS[produto.idCategoria] || "Categoria não informada";

    if (titulo) titulo.textContent = produto.nome || "Produto";
    if (subtitulo) subtitulo.textContent = categoria;

    if (!area) return;
    area.innerHTML = "";

    const card = document.createElement("section");
    card.className = "produto-detalhe-card";

    const preco = formatarPreco(produto.preco);
    const estoque = Number(produto.estoque ?? 0);

    card.innerHTML = `
      <div class="produto-detalhe-topo">
        <div class="produto-imagem-grande">
          <span>🐾</span>
        </div>
        <div class="produto-resumo">
          <p class="produto-categoria">${categoria}</p>
          <h2>${produto.nome || "Produto"}</h2>
          <p class="produto-id-detalhe"><strong>ID:</strong> #${produto.id ?? "—"}</p>
          <p class="produto-descricao">${produto.descricao || "Sem descrição disponível."}</p>
          <p class="produto-preco">R$ ${preco}</p>
          <p class="produto-estoque">Quantidade em estoque: <strong>${estoque}</strong></p>
          <p class="produto-status ${estoque > 0 ? "estoque-ok" : "estoque-zero"}">${estoque > 0 ? "Disponível para compra" : "Sem estoque no momento"}</p>
        </div>
      </div>
    `;

    const detalhes = document.createElement("div");
    detalhes.className = "produto-detalhes-lista";
    detalhes.appendChild(criarLinha("ID", `#${produto.id ?? "—"}`));
    detalhes.appendChild(criarLinha("Categoria", categoria));
    detalhes.appendChild(criarLinha("Preço", `R$ ${preco}`));
    detalhes.appendChild(criarLinha("Estoque", estoque));
    detalhes.appendChild(criarLinha("Descrição", produto.descricao || "Sem descrição disponível."));

    card.appendChild(detalhes);
    area.appendChild(card);
  } catch (erro) {
    if (area) area.innerHTML = '<div class="produto-mensagem">Não foi possível carregar este produto.</div>';
    if (titulo) titulo.textContent = "Produto";
    if (subtitulo) subtitulo.textContent = "Tente novamente.";
  }
}

document.addEventListener("DOMContentLoaded", carregarProduto);
