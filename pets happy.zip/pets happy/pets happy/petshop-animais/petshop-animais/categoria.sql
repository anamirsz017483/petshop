-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28/04/2026 às 19:59
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop`
--

-- --------------------------------------------------------
-- Estrutura para tabela `categoria`
-- --------------------------------------------------------

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categoria` (`id_categoria`, `nome`, `descricao`, `ativo`) VALUES
(1, 'Cachorros', 'Produtos para cães', 1),
(2, 'Gatos', 'Produtos para gatos', 1),
(3, 'Coelhos', 'Produtos para coelhos', 1),
(4, 'Pandas', 'Produtos para pandas', 1);

ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

-- --------------------------------------------------------
-- Estrutura para tabela `produto`
-- --------------------------------------------------------

CREATE TABLE `produto` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` double DEFAULT NULL,
  `id_categoria` int(11) NOT NULL,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `produto` (`id`, `nome`, `descricao`, `preco`, `id_categoria`, `estoque`, `ativo`) VALUES
(1, 'Ração Premium', 'Ração completa para cães adultos, com nutrientes essenciais para energia, pelagem bonita e uma rotina saudável.', 79.90, 1, 18, 1),
(2, 'Coleira Ajustável', 'Coleira resistente e confortável para passeios mais seguros, com ajuste fácil e encaixe prático.', 34.90, 1, 32, 1),
(3, 'Caminha Macia', 'Caminha aconchegante para descanso diário, com toque suave e apoio confortável para o pet.', 129.90, 1, 12, 1),
(4, 'Brinquedo Mordedor', 'Brinquedo interativo que ajuda na distração, no gasto de energia e no bem-estar do cão.', 24.90, 1, 45, 1),
(5, 'Ração Sabor Frango', 'Alimento balanceado para gatos, com sabor agradável e composição pensada para a saúde diária.', 44.90, 2, 20, 1),
(6, 'Arranhador', 'Arranhador funcional para estimular o comportamento natural do gato e proteger os móveis.', 89.90, 2, 11, 1),
(7, 'Fonte de Água', 'Fonte com fluxo contínuo para incentivar a hidratação e deixar a água sempre fresca.', 129.90, 2, 9, 1),
(8, 'Caixa de Areia', 'Caixa prática para higiene diária, com uso simples e limpeza facilitada.', 79.90, 2, 22, 1),
(9, 'Alimento para Coelhos', 'Alimento rico em fibras e nutrientes naturais para uma rotina alimentar equilibrada.', 39.90, 3, 27, 1),
(10, 'Casinha de Coelho', 'Casinha confortável e segura para descanso, abrigo e momentos de tranquilidade.', 119.90, 3, 8, 1),
(11, 'Feno Natural', 'Feno natural essencial para a digestão e para uma alimentação saudável do coelhinho.', 24.90, 3, 40, 1),
(12, 'Brinquedo Interativo', 'Brinquedo leve e divertido que estimula movimento, curiosidade e atividade física.', 29.90, 3, 17, 1),
(13, 'Bambu Selecionado', 'Bambu fresco e selecionado para uma alimentação natural e cheia de energia.', 49.90, 4, 14, 1),
(14, 'Pelúcia Panda', 'Pelúcia fofinha para companhia, conforto e momentos de diversão.', 34.90, 4, 25, 1),
(15, 'Tapete Confortável', 'Tapete macio para descanso agradável e sensação de aconchego.', 94.90, 4, 10, 1),
(16, 'Kit Enriquecimento', 'Kit com itens para estímulo diário, diversão e rotina mais ativa.', 59.90, 4, 16, 1);

ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `produto`
  ADD KEY `idx_produto_categoria` (`id_categoria`);

ALTER TABLE `produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

ALTER TABLE `produto`
  ADD CONSTRAINT `fk_produto_categoria`
  FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
  ON DELETE CASCADE ON UPDATE CASCADE;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
