-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28/04/2026 às 19:59
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop`
--

-- --------------------------------------------------------
-- Estrutura para tabela `categoria`
-- --------------------------------------------------------

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categoria` (`id_categoria`, `nome`, `descricao`, `ativo`) VALUES
(1, 'Cachorros', 'Produtos para cães', 1),
(2, 'Gatos', 'Produtos para gatos', 1),
(3, 'Coelhos', 'Produtos para coelhos', 1),
(4, 'Pandas', 'Produtos para pandas', 1);

ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

-- --------------------------------------------------------
-- Estrutura para tabela `produto`
-- --------------------------------------------------------

CREATE TABLE `produto` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` double DEFAULT NULL,
  `id_categoria` int(11) NOT NULL,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `produto` (`id`, `nome`, `descricao`, `preco`, `id_categoria`, `estoque`, `ativo`) VALUES
(1, 'Ração Premium', 'Alimentação balanceada para cães', 79.90, 1, 18, 1),
(2, 'Coleira Ajustável', 'Mais segurança nos passeios', 34.90, 1, 32, 1),
(3, 'Caminha Macia', 'Conforto para o descanso', 129.90, 1, 12, 1),
(4, 'Brinquedo Mordedor', 'Ajuda na distração e no bem-estar', 24.90, 1, 45, 1),
(5, 'Ração Sabor Frango', 'Alimento balanceado para gatos', 44.90, 2, 20, 1),
(6, 'Arranhador', 'Protege móveis e diverte', 89.90, 2, 11, 1),
(7, 'Fonte de Água', 'Ajuda na hidratação diária', 129.90, 2, 9, 1),
(8, 'Caixa de Areia', 'Higiene prática para o dia a dia', 79.90, 2, 22, 1),
(9, 'Alimento para Coelhos', 'Rico em nutrientes naturais', 39.90, 3, 27, 1),
(10, 'Casinha de Coelho', 'Espaço confortável e seguro', 119.90, 3, 8, 1),
(11, 'Feno Natural', 'Essencial para saúde digestiva', 24.90, 3, 40, 1),
(12, 'Brinquedo Interativo', 'Estimula atividade física', 29.90, 3, 17, 1),
(13, 'Bambu Selecionado', 'Alimentação natural e fresquinha', 49.90, 4, 14, 1),
(14, 'Pelúcia Panda', 'Companhia divertida e fofinha', 34.90, 4, 25, 1),
(15, 'Tapete Confortável', 'Descanso macio e agradável', 94.90, 4, 10, 1),
(16, 'Kit Enriquecimento', 'Diversão e estímulo diário', 59.90, 4, 16, 1);

ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `produto`
  ADD KEY `idx_produto_categoria` (`id_categoria`);

ALTER TABLE `produto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

ALTER TABLE `produto`
  ADD CONSTRAINT `fk_produto_categoria`
  FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
  ON DELETE CASCADE ON UPDATE CASCADE;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
