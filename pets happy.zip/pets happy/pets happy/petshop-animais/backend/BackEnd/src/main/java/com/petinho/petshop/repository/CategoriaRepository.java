package com.petinho.petshop.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.petinho.petshop.model.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
    List<Categoria> findByAtivoTrue();
}
