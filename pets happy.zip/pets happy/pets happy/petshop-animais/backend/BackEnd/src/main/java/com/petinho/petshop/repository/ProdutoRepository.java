package com.petinho.petshop.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.petinho.petshop.model.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
    List<Produto> findByIdCategoriaAndAtivoTrueOrderByIdAsc(Integer idCategoria);
    List<Produto> findByAtivoTrueOrderByIdAsc();
    Optional<Produto> findByIdAndAtivoTrue(Integer id);
}
