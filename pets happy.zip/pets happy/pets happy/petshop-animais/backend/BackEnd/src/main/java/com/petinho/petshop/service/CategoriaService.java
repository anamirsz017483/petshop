package com.petinho.petshop.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.petinho.petshop.model.Categoria;
import com.petinho.petshop.repository.CategoriaRepository;

@Service
public class CategoriaService {

    private final CategoriaRepository repository;

    public CategoriaService(CategoriaRepository repository) {
        this.repository = repository;
    }

    public List<Categoria> listar() {
        return repository.findByAtivoTrue();
    }
}
