package com.petinho.petshop.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.petinho.petshop.model.Produto;
import com.petinho.petshop.repository.ProdutoRepository;

@Service
public class ProdutoService {

    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    public List<Produto> listar() {
        return repository.findByAtivoTrueOrderByIdAsc();
    }

    public List<Produto> getProdutosPorCategoria(Integer idCategoria) {
        return repository.findByIdCategoriaAndAtivoTrueOrderByIdAsc(idCategoria);
    }

    public Optional<Produto> buscarPorId(Integer id) {
        return repository.findByIdAndAtivoTrue(id);
    }
}
