package com.petinho.petshop.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.petinho.petshop.model.Categoria;
import com.petinho.petshop.model.Produto;
import com.petinho.petshop.repository.CategoriaRepository;
import com.petinho.petshop.repository.ProdutoRepository;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner initData(CategoriaRepository categoriaRepository, ProdutoRepository produtoRepository) {
        return args -> {
            produtoRepository.deleteAll();
            categoriaRepository.deleteAll();

            Categoria cachorros = salvarCategoria(categoriaRepository, "Cachorros", "Produtos para cães");
            Categoria gatos = salvarCategoria(categoriaRepository, "Gatos", "Produtos para gatos");
            Categoria coelhos = salvarCategoria(categoriaRepository, "Coelhos", "Produtos para coelhos");
            Categoria pandas = salvarCategoria(categoriaRepository, "Pandas", "Produtos para pandas");

            List<Produto> produtos = Arrays.asList(
                produto("Ração Premium", "Ração completa para cães adultos, com nutrientes essenciais para energia, pelagem bonita e uma rotina saudável.", 79.90, 18, cachorros.getIdCategoria()),
                produto("Coleira Ajustável", "Coleira resistente e confortável para passeios mais seguros, com ajuste fácil e encaixe prático.", 34.90, 32, cachorros.getIdCategoria()),
                produto("Caminha Macia", "Caminha aconchegante para descanso diário, com toque suave e apoio confortável para o pet.", 129.90, 12, cachorros.getIdCategoria()),
                produto("Brinquedo Mordedor", "Brinquedo interativo que ajuda na distração, no gasto de energia e no bem-estar do cão.", 24.90, 45, cachorros.getIdCategoria()),

                produto("Ração Sabor Frango", "Alimento balanceado para gatos, com sabor agradável e composição pensada para a saúde diária.", 44.90, 20, gatos.getIdCategoria()),
                produto("Arranhador", "Arranhador funcional para estimular o comportamento natural do gato e proteger os móveis.", 89.90, 11, gatos.getIdCategoria()),
                produto("Fonte de Água", "Fonte com fluxo contínuo para incentivar a hidratação e deixar a água sempre fresca.", 129.90, 9, gatos.getIdCategoria()),
                produto("Caixa de Areia", "Caixa prática para higiene diária, com uso simples e limpeza facilitada.", 79.90, 22, gatos.getIdCategoria()),

                produto("Alimento para Coelhos", "Alimento rico em fibras e nutrientes naturais para uma rotina alimentar equilibrada.", 39.90, 27, coelhos.getIdCategoria()),
                produto("Casinha de Coelho", "Casinha confortável e segura para descanso, abrigo e momentos de tranquilidade.", 119.90, 8, coelhos.getIdCategoria()),
                produto("Feno Natural", "Feno natural essencial para a digestão e para uma alimentação saudável do coelhinho.", 24.90, 40, coelhos.getIdCategoria()),
                produto("Brinquedo Interativo", "Brinquedo leve e divertido que estimula movimento, curiosidade e atividade física.", 29.90, 17, coelhos.getIdCategoria()),

                produto("Bambu Selecionado", "Bambu fresco e selecionado para uma alimentação natural e cheia de energia.", 49.90, 14, pandas.getIdCategoria()),
                produto("Pelúcia Panda", "Pelúcia fofinha para companhia, conforto e momentos de diversão.", 34.90, 25, pandas.getIdCategoria()),
                produto("Tapete Confortável", "Tapete macio para descanso agradável e sensação de aconchego.", 94.90, 10, pandas.getIdCategoria()),
                produto("Kit Enriquecimento", "Kit com itens para estímulo diário, diversão e rotina mais ativa.", 59.90, 16, pandas.getIdCategoria())
            );

            produtoRepository.saveAll(produtos);
        };
    }

    private Categoria salvarCategoria(CategoriaRepository categoriaRepository, String nome, String descricao) {
        Categoria categoria = new Categoria();
        categoria.setNome(nome);
        categoria.setDescricao(descricao);
        categoria.setAtivo(true);
        return categoriaRepository.save(categoria);
    }

    private Produto produto(String nome, String descricao, Double preco, Integer estoque, Integer idCategoria) {
        Produto p = new Produto();
        p.setNome(nome);
        p.setDescricao(descricao);
        p.setPreco(preco);
        p.setEstoque(estoque);
        p.setIdCategoria(idCategoria);
        p.setAtivo(true);
        return p;
    }
}
