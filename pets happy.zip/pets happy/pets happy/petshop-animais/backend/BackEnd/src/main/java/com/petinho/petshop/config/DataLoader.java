package com.petinho.petshop.config;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.petinho.petshop.model.Categoria;
import com.petinho.petshop.model.Produto;
import com.petinho.petshop.repository.CategoriaRepository;
import com.petinho.petshop.repository.ProdutoRepository;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner initData(CategoriaRepository categoriaRepository, ProdutoRepository produtoRepository) {
        return args -> {
            Categoria cachorros = garantirCategoria(categoriaRepository, "Cachorros", "Produtos para cães");
            Categoria gatos = garantirCategoria(categoriaRepository, "Gatos", "Produtos para gatos");
            Categoria coelhos = garantirCategoria(categoriaRepository, "Coelhos", "Produtos para coelhos");
            Categoria pandas = garantirCategoria(categoriaRepository, "Pandas", "Produtos para pandas");

            if (produtoRepository.count() == 0) {
                salvarProduto(produtoRepository, "Ração Premium", "Ração completa para cães adultos, com nutrientes essenciais para energia, pelagem bonita e uma rotina saudável.", 79.90, 18, cachorros.getIdCategoria());
                salvarProduto(produtoRepository, "Coleira Ajustável", "Coleira resistente e confortável para passeios mais seguros, com ajuste fácil e encaixe prático.", 34.90, 32, cachorros.getIdCategoria());
                salvarProduto(produtoRepository, "Caminha Macia", "Caminha aconchegante para descanso diário, com toque suave e apoio confortável para o pet.", 129.90, 12, cachorros.getIdCategoria());
                salvarProduto(produtoRepository, "Brinquedo Mordedor", "Brinquedo interativo que ajuda na distração, no gasto de energia e no bem-estar do cão.", 24.90, 45, cachorros.getIdCategoria());

                salvarProduto(produtoRepository, "Ração Sabor Frango", "Alimento balanceado para gatos, com sabor agradável e composição pensada para a saúde diária.", 44.90, 20, gatos.getIdCategoria());
                salvarProduto(produtoRepository, "Arranhador", "Arranhador funcional para estimular o comportamento natural do gato e proteger os móveis.", 89.90, 11, gatos.getIdCategoria());
                salvarProduto(produtoRepository, "Fonte de Água", "Fonte com fluxo contínuo para incentivar a hidratação e deixar a água sempre fresca.", 129.90, 9, gatos.getIdCategoria());
                salvarProduto(produtoRepository, "Caixa de Areia", "Caixa prática para higiene diária, com uso simples e limpeza facilitada.", 79.90, 22, gatos.getIdCategoria());

                salvarProduto(produtoRepository, "Alimento para Coelhos", "Alimento rico em fibras e nutrientes naturais para uma rotina alimentar equilibrada.", 39.90, 27, coelhos.getIdCategoria());
                salvarProduto(produtoRepository, "Casinha de Coelho", "Casinha confortável e segura para descanso, abrigo e momentos de tranquilidade.", 119.90, 8, coelhos.getIdCategoria());
                salvarProduto(produtoRepository, "Feno Natural", "Feno natural essencial para a digestão e para uma alimentação saudável do coelhinho.", 24.90, 40, coelhos.getIdCategoria());
                salvarProduto(produtoRepository, "Brinquedo Interativo", "Brinquedo leve e divertido que estimula movimento, curiosidade e atividade física.", 29.90, 17, coelhos.getIdCategoria());

                salvarProduto(produtoRepository, "Bambu Selecionado", "Bambu fresco e selecionado para uma alimentação natural e cheia de energia.", 49.90, 14, pandas.getIdCategoria());
                salvarProduto(produtoRepository, "Pelúcia Panda", "Pelúcia fofinha para companhia, conforto e momentos de diversão.", 34.90, 25, pandas.getIdCategoria());
                salvarProduto(produtoRepository, "Tapete Confortável", "Tapete macio para descanso agradável e sensação de aconchego.", 94.90, 10, pandas.getIdCategoria());
                salvarProduto(produtoRepository, "Kit Enriquecimento", "Kit com itens para estímulo diário, diversão e rotina mais ativa.", 59.90, 16, pandas.getIdCategoria());
            }
        };
    }

    private Categoria garantirCategoria(CategoriaRepository categoriaRepository, String nome, String descricao) {
        List<Categoria> categorias = categoriaRepository.findAll();
        for (Categoria categoria : categorias) {
            if (categoria.getNome() != null && categoria.getNome().equalsIgnoreCase(nome)) {
                return categoria;
            }
        }

        Categoria categoria = new Categoria();
        categoria.setNome(nome);
        categoria.setDescricao(descricao);
        categoria.setAtivo(true);
        return categoriaRepository.save(categoria);
    }

    private void salvarProduto(ProdutoRepository repository, String nome, String descricao, Double preco, Integer estoque, Integer idCategoria) {
        Produto p = new Produto();
        p.setNome(nome);
        p.setDescricao(descricao);
        p.setPreco(preco);
        p.setEstoque(estoque);
        p.setIdCategoria(idCategoria);
        p.setAtivo(true);
        repository.save(p);
    }
}
