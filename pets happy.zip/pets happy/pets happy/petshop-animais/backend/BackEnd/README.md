# Petshop Backend

Backend Spring Boot pronto para importar no Eclipse.

## Como importar no Eclipse
1. Extraia este ZIP.
2. No Eclipse, vá em **File > Import > Maven > Existing Maven Projects**.
3. Em **Root Directory**, selecione a pasta **BackEnd** (a mesma pasta que contém o `pom.xml`).
4. Não selecione a pasta `src`.
5. Clique em **Finish**.

## Como executar
- Rode a classe `com.petinho.petshop.PetshopApplication`.
- O backend sobe em `http://localhost:8080`.

## Endpoints
- `GET /api/categorias`
- `GET /api/produtos`
- `GET /api/produtos/categoria/{idCategoria}`
- `GET /api/produtos/{id}`

## Banco
Este projeto usa H2 em memória, então não precisa configurar MySQL para funcionar.
