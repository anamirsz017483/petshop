
const API_BASE = "http://localhost:8080/api/produtos";

function buscar() {
    const termo = document.getElementById('pesquisa').value.toLowerCase();
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        const nome = card.querySelector('h2').textContent.toLowerCase();
        card.style.display = nome.includes(termo) ? 'flex' : 'none';
    });
}

document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && document.activeElement?.id === "pesquisa") {
        buscar();
    }
});

const descricoes = {
    cachorro: "Os cães são mamíferos carnívoros da família Canidae, conhecidos por sua lealdade, companheirismo e capacidade de aprendizagem. São animais sociais, adaptáveis e precisam de atenção, alimentação equilibrada e cuidados veterinários regulares.",
    gato: "Os gatos são mamíferos carnívoros da família Felidae, famosos pela agilidade, independência e comportamento limpo. Como pets, exigem boa alimentação, água fresca, higiene e acompanhamento veterinário.",
    coelho: "Os coelhos são mamíferos herbívoros da ordem Lagomorpha, conhecidos pelas orelhas longas e pelos dentes que crescem continuamente. São silenciosos, sociáveis e precisam de feno, água, espaço seguro e alimentação apropriada.",
    panda: "Os pandas são mamíferos da família Ursidae, conhecidos pela pelagem preta e branca e pela alimentação baseada em bambu. São animais simbólicos e precisam de cuidados ambientais e alimentação especial."
};

function mostrarDescricao(categoria) {
    const titulos = {
        cachorro: "Cachorro",
        gato: "Gato",
        coelho: "Coelho",
        panda: "Panda"
    };

    document.getElementById('modalTitulo').textContent = titulos[categoria];
    document.getElementById('modalDescricao').textContent = descricoes[categoria];
    document.getElementById('descricaoModal').style.display = 'block';
}

function fecharModal() {
    document.getElementById('descricaoModal').style.display = 'none';
}

window.addEventListener("click", (event) => {
    const modal = document.getElementById('descricaoModal');
    if (event.target === modal) modal.style.display = 'none';
});

async function carregarCategoriasHome() {
    const area = document.getElementById("categoriasHome");
    if (!area) return;

    const categorias = [
        { idCategoria: 1, nome: "Cachorro", img: "cachorro.jpg", href: "cachorro.html" },
        { idCategoria: 2, nome: "Gato", img: "gato.jpg", href: "gato.html" },
        { idCategoria: 3, nome: "Coelho", img: "coelho.jpg", href: "coelho.html" },
        { idCategoria: 4, nome: "Panda", img: "panda.jpg", href: "panda.html" }
    ];

    area.innerHTML = categorias.map(cat => `
        <a class="card" href="${cat.href}" onclick="return true;">
            <div class="img-container">
                <img src="${cat.img}" alt="${cat.nome}">
            </div>
            <h2>${cat.nome}</h2>
        </a>
    `).join("");
}

document.addEventListener("DOMContentLoaded", carregarCategoriasHome);
