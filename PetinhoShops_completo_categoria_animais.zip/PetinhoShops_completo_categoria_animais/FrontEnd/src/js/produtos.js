
const API_BASE = "http://localhost:8080/api/produtos";
const categoriasMap = {
  1: {
    nome: "Cachorros 🐶",
    plural: "Cachorros",
    hero: "Produtos para Cachorros 🐶",
    subtitulo: "Tudo para cuidar do seu cão com conforto, saúde e carinho.",
    corHeader: "#f57c20",
    corHero: "#e5397a",
    busca: "Buscar produtos para cachorros...",
    fallback: [
      { nome: "Ração Premium", descricao: "Alimentação balanceada para cães", preco: 79.90, emoji: "🥣" },
      { nome: "Coleira Ajustável", descricao: "Mais segurança nos passeios", preco: 34.90, emoji: "🦴" },
      { nome: "Caminha Macia", descricao: "Conforto para o descanso", preco: 129.90, emoji: "🛏️" },
      { nome: "Brinquedo Mordedor", descricao: "Ajuda na distração e no bem-estar", preco: 24.90, emoji: "🧸" }
    ]
  },
  2: {
    nome: "Gatos 🐱",
    plural: "Gatos",
    hero: "Produtos para Gatos 🐱",
    subtitulo: "Itens para deixar o seu gato feliz, ativo e bem cuidado.",
    corHeader: "#ff6f61",
    corHero: "#8e44ad",
    busca: "Buscar produtos para gatos...",
    fallback: [
      { nome: "Ração Sabor Frango", descricao: "Alimento balanceado para gatos", preco: 44.90, emoji: "🥣" },
      { nome: "Arranhador", descricao: "Protege móveis e diverte", preco: 89.90, emoji: "🪵" },
      { nome: "Fonte de Água", descricao: "Ajuda na hidratação diária", preco: 129.90, emoji: "💧" },
      { nome: "Caixa de Areia", descricao: "Higiene prática para o dia a dia", preco: 79.90, emoji: "🧼" }
    ]
  },
  3: {
    nome: "Coelhos 🐰",
    plural: "Coelhos",
    hero: "Produtos para Coelhos 🐰",
    subtitulo: "Tudo para cuidar do seu coelhinho com conforto, saúde e carinho.",
    corHeader: "#f57c20",
    corHero: "#e83e8c",
    busca: "Buscar produtos para coelhos...",
    fallback: [
      { nome: "Alimento para Coelhos", descricao: "Rico em nutrientes naturais", preco: 39.90, emoji: "🥕" },
      { nome: "Casinha de Coelho", descricao: "Espaço confortável e seguro", preco: 119.90, emoji: "🏠" },
      { nome: "Feno Natural", descricao: "Essencial para saúde digestiva", preco: 24.90, emoji: "🌿" },
      { nome: "Brinquedo Interativo", descricao: "Estimula atividade física", preco: 29.90, emoji: "🎾" }
    ]
  },
  4: {
    nome: "Pandas 🐼",
    plural: "Pandas",
    hero: "Produtos para Pandas 🐼",
    subtitulo: "Acessórios e itens especiais para um panda cheio de estilo.",
    corHeader: "#2d9cdb",
    corHero: "#2ecc71",
    busca: "Buscar produtos para pandas...",
    fallback: [
      { nome: "Bambu Selecionado", descricao: "Alimentação natural e fresquinha", preco: 49.90, emoji: "🎋" },
      { nome: "Pelúcia Panda", descricao: "Companhia divertida e fofinha", preco: 34.90, emoji: "🧸" },
      { nome: "Tapete Confortável", descricao: "Descanso macio e agradável", preco: 94.90, emoji: "🛋️" },
      { nome: "Kit Enriquecimento", descricao: "Diversão e estímulo diário", preco: 59.90, emoji: "🎮" }
    ]
  }
};

function getCategoriaIdFromPage() {
  const params = new URLSearchParams(window.location.search);
  const q = params.get("categoria");
  if (q) return Number(q);

  const bodyClass = document.body?.dataset?.categoriaId;
  if (bodyClass) return Number(bodyClass);

  return null;
}

function getCategoriaTitulo(id) {
  return categoriasMap[id]?.hero || "Produtos por Categoria";
}

function formatarPreco(valor) {
  return Number(valor || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function montarCard(prod, allowComprar = true) {
  const card = document.createElement("article");
  card.className = "produto-card";

  const imageHtml = prod.imagem
    ? `<img src="${prod.imagem}" alt="${prod.nome || 'Produto'}">`
    : `<div class="emoji-produto">${prod.emoji || "🐾"}</div>`;

  card.innerHTML = `
    ${imageHtml}
    <h3>${prod.nome || ""}</h3>
    <p>${prod.descricao || ""}</p>
    <p class="preco">R$ ${formatarPreco(prod.preco)}</p>
    ${allowComprar ? '<button class="btn-comprar" type="button">Comprar</button>' : ''}
  `;

  return card;
}

async function buscarProdutosDaApi(categoriaId) {
  try {
    const res = await fetch(`http://localhost:8080/api/produtos/categoria/${categoriaId}`);
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch (e) {
    return [];
  }
}

function combinarProdutos(apiProdutos, fallbackProdutos) {
  const lista = [];

  apiProdutos.slice(0, 4).forEach(p => {
    lista.push({
      nome: p.nome || "Produto",
      descricao: p.descricao || "",
      preco: p.preco ?? 0,
      imagem: p.imagem || "",
      emoji: p.emoji || "🐾"
    });
  });

  if (lista.length < 4) {
    fallbackProdutos.forEach(p => {
      if (lista.length < 4) lista.push(p);
    });
  }

  return lista.slice(0, 4);
}

async function renderCategoriaUnica(categoriaId) {
  const area = document.getElementById("areaProdutos");
  const msg = document.getElementById("mensagem");
  const titulo = document.getElementById("titulo");
  const subtitulo = document.getElementById("subtitulo");

  const cat = categoriasMap[categoriaId];
  if (!cat) {
    titulo.textContent = "Produtos por Categoria";
    subtitulo.textContent = "Escolha uma categoria.";
    msg.style.display = "block";
    msg.textContent = "Categoria inválida.";
    return;
  }

  document.querySelector("header") && (document.querySelector("header").style.background = cat.corHeader);
  document.querySelector(".hero") && (document.querySelector(".hero").style.background = cat.corHero);

  titulo.textContent = cat.hero;
  subtitulo.textContent = cat.subtitulo;

  const apiProdutos = await buscarProdutosDaApi(categoriaId);
  const produtos = combinarProdutos(apiProdutos, cat.fallback);

  area.innerHTML = "";
  msg.style.display = "none";

  const bloco = document.createElement("section");
  bloco.className = "categoria-bloco";

  const h2 = document.createElement("h2");
  h2.className = "categoria-titulo";
  h2.textContent = cat.nome;

  const grid = document.createElement("div");
  grid.className = "produtos-grid";

  produtos.forEach(prod => grid.appendChild(montarCard(prod, true)));

  bloco.appendChild(h2);
  bloco.appendChild(grid);
  area.appendChild(bloco);
}

async function renderTodasCategorias() {
  const area = document.getElementById("areaProdutos");
  const msg = document.getElementById("mensagem");
  const titulo = document.getElementById("titulo");
  const subtitulo = document.getElementById("subtitulo");

  titulo.textContent = "Produtos por Categoria";
  subtitulo.textContent = "Cachorros, Gatos, Coelhos e Pandas";

  area.innerHTML = "";
  msg.style.display = "none";

  const ids = [1, 2, 3, 4];

  for (const id of ids) {
    const cat = categoriasMap[id];
    const apiProdutos = await buscarProdutosDaApi(id);
    const produtos = combinarProdutos(apiProdutos, cat.fallback);

    const bloco = document.createElement("section");
    bloco.className = "categoria-bloco";

    const cab = document.createElement("div");
    cab.className = "cabecalho-categoria";
    cab.innerHTML = `
      <h2>${cat.nome}</h2>
      <a class="link-categoria" href="produtos.html?categoria=${id}">Ver todos</a>
    `;

    const grid = document.createElement("div");
    grid.className = "produtos-grid";

    produtos.forEach(prod => grid.appendChild(montarCard(prod, true)));

    bloco.appendChild(cab);
    bloco.appendChild(grid);
    area.appendChild(bloco);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  const categoriaId = getCategoriaIdFromPage();
  if (categoriaId) {
    await renderCategoriaUnica(categoriaId);
  } else {
    await renderTodasCategorias();
  }
});
