
package com.petinho.petshop.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.petinho.petshop.model.Produto;
import com.petinho.petshop.service.ProdutoService;

@RestController
@RequestMapping("/api/produtos")
@CrossOrigin("*")
public class ProdutoController {

    @Autowired
    private ProdutoService service;

    // Endpoint: todos os produtos de uma categoria
    @GetMapping("/categoria/{idCategoria}")
    public List<Produto> getProdutosByCategoria(@PathVariable Integer idCategoria) {
        return service.getProdutosPorCategoria(idCategoria);
    }
}
