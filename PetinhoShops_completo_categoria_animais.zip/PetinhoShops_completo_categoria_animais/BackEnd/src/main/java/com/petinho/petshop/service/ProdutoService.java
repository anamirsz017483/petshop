
package com.petinho.petshop.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.petinho.petshop.model.Produto;
import com.petinho.petshop.repository.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    // Retorna todos os produtos ativos de uma categoria
    public List<Produto> getProdutosPorCategoria(Integer id_categoria) {
        return repository.findByIdCategoriaAndAtivoTrue(id_categoria);
    }
}
